package com.bignerdranch.android.jchao_hw3;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class HW3Activity extends AppCompatActivity {

    private TextView mInstructionsTextView;
    private TextView mChoicesTextView;
    private TextView mQuantityATextView;
    private TextView mQuantityBTextView;
    private TextView mQuestionTextView;
    private TextView mQuestQuantATextView;
    private TextView mQuestQuantBTextView;
    private Button mAButton;
    private Button mBButton;
    private Button mCButton;
    private Button mDButton;
    private ImageButton mNextButton;
    private ImageButton mPrevButton;
    private Button mHintButton;

    private boolean wasHintUsed;

    private static final String TAG = "QuizActivity";
    private static final String KEY_INDEX = "index";
    private static final String KEY_INDEX2 = "index2";
    private static final String KEY_INDEX3 = "index3";
    private static final String KEY_INDEX4 = "index4";

    private static final int REQUEST_CODE_HINT = 0;

    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.question_1, "D", false),
            new Question(R.string.question_2, "B", false),
            new Question(R.string.question_3, "D", false),
            new Question(R.string.question_4, "C", false),
            new Question(R.string.question_5, "B", false),
    };

    // Array of booleans with store whether a hint for a question was used.  Used for save states.
    private boolean[] mUsedHint = {false, false, false, false, false};

    // Array of booleans which store whether a question has been answered.  Used for save states.
    private boolean[] mIsQuestionAnswered = {false, false, false, false, false};

    // Array used to store quantities that correspond to the questions.
    private Quantities[] mAnswerBank = new Quantities[] {
            new Quantities(R.string.question_1a, R.string.question_1b),
            new Quantities(R.string.question_2a, R.string.question_2b),
            new Quantities(R.string.question_3a, R.string.question_3b),
            new Quantities(R.string.question_4a, R.string.question_4b),
            new Quantities(R.string.question_5a, R.string.question_5b),
    };

    private int mCurrentIndex = 0;
    private float grade = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Restore saved state information.
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate(Bundle) called");
        setContentView(R.layout.activity_hw3);

        if (savedInstanceState != null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
            grade = savedInstanceState.getFloat(KEY_INDEX3, 0);
            mUsedHint = savedInstanceState.getBooleanArray(KEY_INDEX4);

            mIsQuestionAnswered = savedInstanceState.getBooleanArray(KEY_INDEX2);
            for(int i=0; i < mIsQuestionAnswered.length; i++){
                mQuestionBank[i].setAnswered(mIsQuestionAnswered[i]);
            }
        }

        // Instructions and choice descriptions
        mInstructionsTextView = (TextView) findViewById(R.id.app_instructions);
        mInstructionsTextView.setText(R.string.instructions);

        mChoicesTextView = (TextView) findViewById(R.id.app_choices);
        mChoicesTextView.setText(R.string.choices);

        // Display questions and quantities
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        mQuestionTextView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (mCurrentIndex < mQuestionBank.length - 1){
                    mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
                    updateQuestion();
                }
            }
        });

        mQuantityATextView = (TextView) findViewById(R.id.quantity_a);
        mQuantityATextView.setText(R.string.quantity_a_label);
        mQuestQuantATextView = (TextView) findViewById(R.id.question_quant_a);

        mQuantityBTextView = (TextView) findViewById(R.id.quantity_b);
        mQuantityBTextView.setText(R.string.quantity_b_label);
        mQuestQuantBTextView = (TextView) findViewById(R.id.question_quant_b);

        // Buttons for the choices
        mAButton = (Button) findViewById(R.id.a_button);
        mAButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                checkAnswer("A", mCurrentIndex);
            }
        });

        mBButton = (Button) findViewById(R.id.b_button);
        mBButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                checkAnswer("B", mCurrentIndex);
            }
        });

        mCButton = (Button) findViewById(R.id.c_button);
        mCButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                checkAnswer("C", mCurrentIndex);
            }
        });

        mDButton = (Button) findViewById(R.id.d_button);
        mDButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                checkAnswer("D", mCurrentIndex);
            }
        });

        // Previous and Next buttons to skip questions
        mPrevButton = (ImageButton) findViewById(R.id.previous_button);
        mPrevButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (mCurrentIndex > 0){
                    //If user is on the first question, then previous button does nothing!
                    mCurrentIndex = (mCurrentIndex /*+ mQuestionBank.length*/ - 1) % mQuestionBank.length;
                    updateQuestion();
                }
            }
        });

        mNextButton = (ImageButton) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (mCurrentIndex < mQuestionBank.length - 1){
                    //If user is on last question, then next button does nothing!
                    mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
                    updateQuestion();
                }
            }
        });

        mHintButton = (Button)findViewById(R.id.hint_button);
        mHintButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //Start HintActivity
                Intent intent = HintActivity.newIntent(HW3Activity.this, mCurrentIndex);
                startActivityForResult(intent, REQUEST_CODE_HINT);
            }
        });

        updateQuestion();
    }

    // Logs
    @Override
    public void onStart(){
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    // This method saves mCurrentIndex so app will not always return to first question on rotation.
    // Also saves boolean array mIsQuestionAnswered so that after rotating app still know what questions were answered.
    // Also saves float grade so after rotation grade is not restarted.
    // Also saves boolean array mUsedHint so after rotation hint counts are not restarted.
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
        savedInstanceState.putBooleanArray(KEY_INDEX2, mIsQuestionAnswered);
        savedInstanceState.putFloat(KEY_INDEX3, grade);
        savedInstanceState.putBooleanArray(KEY_INDEX4, mUsedHint);
    }

    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    //Retrieves the result from the intent
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if (resultCode != Activity.RESULT_OK){
            return;
        }

        // Returns whether or not user used a hint for a particular question.
        if (requestCode == REQUEST_CODE_HINT){
            if (data == null){
                return;
            }
            wasHintUsed = HintActivity.wasHintShown(data);

            // If wasHintUsed returns true, then update the mUsedHint boolean array.
            if(wasHintUsed){
                mUsedHint[mCurrentIndex] = true;
            }
        }
    }

    // Method to update questions and their corresponding quantities.
    private void updateQuestion() {
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
        int quantityA = mAnswerBank[mCurrentIndex].getQuantityA();
        mQuestQuantATextView.setText(quantityA);
        int quantityB = mAnswerBank[mCurrentIndex].getQuantityB();
        mQuestQuantBTextView.setText(quantityB);

        // Turn off answer buttons if question already answered, prevents repeat answers.
        if (mQuestionBank[mCurrentIndex].answered()){
            turnOffButtons();
        }
        else{
            turnOnButtons();
        }

    }

    // Checks if answer is correct.
    private void checkAnswer(String answer, int index) {
        int messageResID = 0;

        // If answer is correct, post correct toast and increment grade.
        if (answer.equals(mQuestionBank[index].getAnswer())){
            messageResID = R.string.correct_toast;
            grade = grade + 1;
        } else {
            messageResID = R.string.incorrect_toast;
        }

        // Finds question in bank, sets isAnswered attribute to true. Turn all answer buttons off.
        mQuestionBank[index].setAnswered(true);
        mIsQuestionAnswered[index] = true;
        turnOffButtons();

        // Post the toast on screen.
        Toast.makeText(this, messageResID, Toast.LENGTH_SHORT).show();

        // Check if all questions are answered.  If true, then a final score is shown.
        if (allAnswered(mQuestionBank)){
            displayScore(mQuestionBank, grade);
        }
    }

    // Method to check if all answers in question bank have been answered.
    private boolean allAnswered(Question[] bank){
        for (int i=0; i < bank.length; i++){
            if (!bank[i].answered()){
                return false;
            }
        }
        return true;
    }

    // Method to calculate and display final score as toast.
    private void displayScore(Question[] bank, float score){
        double percentCorrect = ((score - (.5 * countHint(mUsedHint))) / bank.length) * 100;

        // This accounts for if someone got the question wrong even after using a hint
        if(percentCorrect < 0){
            percentCorrect = 0;
        }

        String message = "You got " + percentCorrect + "%!" + "\nUsed "
                + Math.round(countHint(mUsedHint)) + " hints!";
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Count how many times hints were used
    private float countHint(boolean[] h){
        float count = 0;

        for(int i=0; i < h.length; i++){
            if(h[i] == true){
                count = count + 1;
            }
        }
        return count;
    }

    // Turn all answer buttons on.
    private void turnOnButtons(){
        mAButton.setClickable(true);
        mBButton.setClickable(true);
        mCButton.setClickable(true);
        mDButton.setClickable(true);
        mHintButton.setClickable(true);
    }

    // Turn all answer buttons off.
    private void turnOffButtons(){
        mAButton.setClickable(false);
        mBButton.setClickable(false);
        mCButton.setClickable(false);
        mDButton.setClickable(false);
        mHintButton.setClickable(false);
    }
}
