package com.bignerdranch.android.jchao_hw3;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HintActivity extends AppCompatActivity {

    private static final String EXTRA_HINT = "com.bignerdranch.android.jchao_hw3.hint";
    private static final String HINT_SHOWN = "com.bignerdranch.android.jchao_hw3.hint_shown";
    private static final String TAG = "HintActivity";
    private static final String KEY_INDEX = "index";
    private static final String KEY_INDEX2 = "index2";
    private boolean hintShown = false;
    private int mIndex;

    private TextView mHintTextView;
    private Button mShowHintButton;

    private int[] Hints = new int[]{
            R.string.question_1_hint,
            R.string.question_2_hint,
            R.string.question_3_hint,
            R.string.question_4_hint,
            R.string.question_5_hint
    };

    public static Intent newIntent(Context packageContext, int index){
        Intent intent = new Intent(packageContext, HintActivity.class);
        intent.putExtra(EXTRA_HINT, index);
        return intent;
    }

    public static boolean wasHintShown(Intent result){
        return result.getBooleanExtra(HINT_SHOWN, false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hint);

        mHintTextView = (TextView) findViewById(R.id.hint_text_view);

        // If there is savedInstanceState data, then retrieve mIndex, hintShown, and displays
        // current hint and setHintShown(true).
        if (savedInstanceState != null){
            mIndex = savedInstanceState.getInt(KEY_INDEX, 0);
            hintShown = savedInstanceState.getBoolean(KEY_INDEX2);
            if(hintShown == true){
                mHintTextView.setText(Hints[mIndex]);
                setHintShown(true);
            }
        }

        mIndex = getIntent().getIntExtra(EXTRA_HINT, 0);


        mShowHintButton = (Button) findViewById(R.id.show_hint_button);
        mShowHintButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                mHintTextView.setText(Hints[mIndex]);
                setHintShown(true);
            }
        });
    }

    private void setHintShown(boolean isHintShown){
        Intent data = new Intent();
        data.putExtra(HINT_SHOWN, isHintShown);
        setResult(RESULT_OK, data);
        hintShown = true;
    }

    // This method saves mIndex so app will not always return to first hint on rotation.
    // Also saves boolean hintShown so that after rotating app still shows hint.
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mIndex);
        savedInstanceState.putBoolean(KEY_INDEX2, hintShown);

    }
}
