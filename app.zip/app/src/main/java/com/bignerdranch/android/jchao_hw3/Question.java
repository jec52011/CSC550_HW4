package com.bignerdranch.android.jchao_hw3;

/**
 * Created by Jedrik on 10/15/2017.
 */

public class Question {
    private int mTextResId;
    private String mAnswer;
    private boolean mIsAnswered;

    public Question(int TextResId, String answer, boolean isAnswered){
        mTextResId = TextResId;
        mAnswer = answer;
        mIsAnswered = isAnswered;
    }

    public int getTextResId() {
        return mTextResId;
    }

    public void setTextResId(int textResId) {
        mTextResId = textResId;
    }

    public String getAnswer() {
        return mAnswer;
    }

    public void setAnswer(String answer) {
        mAnswer = answer;
    }

    public boolean answered()
    {
        return mIsAnswered;
    }

    public void setAnswered(boolean isAnswered)
    {
        mIsAnswered = isAnswered;
    }
}
