package com.bignerdranch.android.jchao_hw3;

/**
 * Created by Jedrik on 10/16/2017.
 */

public class Quantities {
    private int quantityA;
    private int quantityB;

    public Quantities(int a, int b){
        quantityA = a;
        quantityB = b;
    }

    public int getQuantityA(){
        return quantityA;
    }

    public void setA(int a){
        quantityA = a;
    }

    public int getQuantityB(){
        return quantityB;
    }

    public void setB(int b){
        quantityB = b;
    }
}
